package com.example.appdotrab;

import androidx.fragment.app.Fragment;

public class TeamFragment extends Fragment {
}
